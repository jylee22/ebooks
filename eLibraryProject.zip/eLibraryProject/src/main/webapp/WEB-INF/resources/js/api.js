/**
 * 
 */
 
$.ajax({
	type: 'get',
	url: '',
	dataType: 'joson',
	contentType: 'application/json; charset=utf-8',
})